package com.app.res.users;

import com.app.res.agents.agentClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin("*")
@RestController
@RequestMapping("api/users")
public class userController {
    private final userService userservice;
    private final userRepository userepository;

    @Autowired

    public userController(userService userservice, userRepository userepository) {
        this.userservice = userservice;
        this.userepository = userepository;
    }

    @GetMapping()
    public List<userClass> getUsers() {
        return userservice.getUsers();
    }
    @PostMapping()
    public void registerUser(@RequestBody userClass userclass){
        userservice.addUsers(userclass);
    }
    @DeleteMapping(path = "{userId}")
    public void deleteUser(@PathVariable ("userId") Long userId){
        userservice.deleteUser(userId);
    }
    @PutMapping(path="{userId}")
    public ResponseEntity<userClass> updateAgent(@PathVariable(value = "userId") Long agentId, @RequestBody userClass new_agent) {
        userClass user = userepository.findById(agentId).orElseThrow(()->new IllegalStateException("error while attempting to delete data"));
        user.setFirstName(new_agent.getFirstName());
        user.setLastName(new_agent.getLastName());
        user.setEmail(new_agent.getEmail());
        user.setPassword(new_agent.getPassword());
        final userClass agent_new = userepository.save(user);
        return ResponseEntity.ok(agent_new);
    }



}
