package com.app.res.users;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class userService {





        public userService(userRepository agentRepository) {
            this.userepository = agentRepository;
        }
        @Autowired
        private final userRepository userepository;
        public List<userClass> getUsers() {
            return userepository.findAll();
        }


        public userClass addUsers(userClass userclass) {
            Optional<userClass> findUserByEmail = userepository.findUserByEmail(userclass.getEmail());
            if(findUserByEmail.isPresent()){
                throw new IllegalStateException("Email already taken");
            }
            return userepository.save(userclass);
        }

        public void deleteUser(Long agentId) {
            boolean exist=userepository.existsById(agentId);
            if(!exist){
                throw new IllegalStateException("Email with id does not exist");
            }
            userepository.deleteById(agentId);

        }
}
